#ifndef SORT_H
#define SORT_H
#include <stddef.h>

void sort_asc(int a[], size_t n);
void sort_des(int a[], size_t n);

#endif
