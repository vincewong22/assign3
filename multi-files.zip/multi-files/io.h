#ifndef IO_H
#define IO_H
#include <stddef.h>

size_t get_ints(int a[], size_t n);
void   print(const int a[], size_t n);

#endif
